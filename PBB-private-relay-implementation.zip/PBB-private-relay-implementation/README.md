# PAC-Bayes with Backprop (PBB)

This repository includes the code associated to the thesis: 

"Better Priors for Neural Networks with Risk Certificates"

It is based on the code used for the "Tigther Risk Certificates for Neural Networks" paper, created by María Pérez-Ortiz. However, a significant amount of new code has been added to the original codebase to extend PBB to PBBR.

-run_dp_experiment.py contains an example of how to run a PBBR experiment
-running_example.py contains an example of how to run a PBBR 2-model experiment

The main components of this repository can be found in the pbb/ folder. 

Additional functionalities will be added in subsequent versions.