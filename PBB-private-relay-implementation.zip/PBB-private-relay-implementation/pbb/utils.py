import math
import numpy as np
import torch
import random
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.distributions as td
from torchvision import datasets, transforms
from torchvision.utils import make_grid
from tqdm import tqdm, trange
from pbb.models import NNet4l, CNNet4l, ProbNNet4l, ProbCNNet4l, ProbCNNet9l, CNNet9l, NNet3l, ProbNNet3l, CNNet13l, ProbCNNet13l, ProbCNNet15l, CNNet15l, trainNNet, testNNet, Lambda_var, trainPNNet, computeRiskCertificates, testPosteriorMean, testStochastic, testEnsemble, trainNNetmixup
from pbb.bounds import PBBobj
from pbb import data
import wandb
import copy
import os
import json
from functools import lru_cache

# TODOS: 
# combine prior_args and posterior_args to a single argument 'bayes_relay_args', for iterative pac-bayes
# expand hyperparameter tuning to raytune option
# Clean up stuff like "learning_rate_prior = prior_net_settings['lr']" so that code is cleaner
# If prior is probabilistic we should be reporting and logging as well the risk of the prior and using computeRiskCertificates


def runexp(experiment_args, prior_args, posterior_args, wandb_args=None):

    """Run an experiment with PAC-Bayes inspired training objectives
    Parameters
    ----------
    experiment_args : dictionary
        contains arguments that define the structure of the overall experiment
    prior_args : dictionary
        contains arguments that define the structure of the prior network
    posterior_args : dictionary
        contains arguments that define the structure of the posterior network
    wandb_args : dictionary
        contains arguments that define the method of logging to Weights & 
        Biases
    """
    prior_net_settings = prior_args
    posterior_net_settings = posterior_args
    experiment_settings = experiment_args

    #log training status with weights & biases
    #check if W&B turned on and haven't initialized run(if it's already been initialized then this is a sweep experiment)
    if wandb_args['log_wandb'] and wandb_args['run_type']!='sweep':
        if wandb_args['scratch_dir'] is not None:
            run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], dir = wandb_args['scratch_dir'], project=wandb_args['wandb_project_name'], config=locals())
        else:
            run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], project=wandb_args['wandb_project_name'], config=locals())
        #if a specific name for the run is passed, set it. Otherwise use auto-generated run name
        if wandb_args.get('wandb_run_name') is not None:
            wandb.run.name = wandb_args['wandb_run_name']
        else:
            wandb.run.name = "dataset: " + experiment_settings['dataset'] + " prior: " + prior_net_settings["objective"] + " posterior: " + posterior_net_settings["objective"]
    experiment_settings['wandb_args'] = wandb_args
    # this makes the initialised prior the same for all bounds
    torch.manual_seed(7)
    random.seed(0)
    np.random.seed(0)
    experiment_settings['RANDOM_STATE'] = 10


    #load some useful initializations into parameter dicts
    experiment_settings['vision_dataset'] = experiment_settings['dataset'] in {'mnist', 'cifar10'}
    experiment_settings['toolarge'] = experiment_settings['model_class'] == 'cnn'
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    experiment_settings['loader_kargs']= {'num_workers': 1,
                    'pin_memory': True} if torch.cuda.is_available() else {}
    # set the hyperparameter of the prior 
    prior_net_settings['rho_prior'] = math.log(math.exp(prior_net_settings['sigma'])-1.0)


    # if basically we just want ERM (usually to be used as a baseline)
    if prior_net_settings["objective"] in ['erm', 'mixup'] and posterior_net_settings['objective'] in ['erm', 'mixup']:
        run_erm_net(prior_net_settings, posterior_net_settings, experiment_settings)
    else:
        run_stochastic_net(prior_net_settings, posterior_net_settings, experiment_settings)


def count_parameters(model): 
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def initialise_prior(model, dataset, layers, dropout_prob, device, objective_prior, rho_prior, prior_dist, init_priors_prior='zeros', features=28*28, classes=10, neurons=100):
    #TODO: only take int prior_settings and experiment_settings
    prob_prior = True
    if objective_prior in {'erm', 'mixup'}: 
        prob_prior = False

    if model == 'cnn':
        if dataset == 'cifar10':
            # only cnn models are tested for cifar10, fcns are only used 
            # with mnist
            if not prob_prior: 
                if layers == 9:
                    prior_net = CNNet9l(dropout_prob=dropout_prob).to(device)
                elif layers == 13:
                    prior_net = CNNet13l(dropout_prob=dropout_prob).to(device)
                elif layers == 15:
                    prior_net = CNNet15l(dropout_prob=dropout_prob).to(device)
                else: 
                    raise RuntimeError(f'Wrong number of layers {layers}')
            else:
                if layers == 9:
                    prior_net = ProbCNNet9l(rho_prior, prior_dist=prior_dist,
                        device=device, init_prior = init_priors_prior).to(device)
                elif layers == 13:
                    prior_net = ProbCNNet13l(rho_prior, prior_dist=prior_dist,
                        device=device, init_prior = init_priors_prior).to(device)
                elif layers == 15:
                    prior_net = ProbCNNet15l(rho_prior, prior_dist=prior_dist,
                        device=device, init_prior = init_priors_prior).to(device)
                else: 
                    raise RuntimeError(f'Wrong number of layers {layers}')
        elif dataset == 'mnist':
            if not prob_prior:
                prior_net = CNNet4l(dropout_prob=dropout_prob).to(device)
            else:
                prior_net = ProbCNNet4l(rho_prior, prior_dist=prior_dist,
                        device=device, init_prior = init_priors_prior).to(device)
        else: 
            raise RuntimeError(f'Wrong dataset')
    else:
        if dataset == 'mnist':
            if prob_prior:
                prior_net = ProbNNet4l(rho_prior, prior_dist=prior_dist,
                            device=device, init_prior = init_priors_prior).to(device)
            else:
                prior_net = NNet4l(dropout_prob=dropout_prob, device=device).to(device)
        else: 
            if prob_prior:
                prior_net = ProbNNet3l(rho_prior, prior_dist='gaussian',
                                    device=device, features=features, classes=classes, neurons=neurons, init_prior='random').to(device)
            else:
                prior_net = NNet3l(dropout_prob=dropout_prob, device=device, features=features, classes=classes, neurons=neurons).to(device)
            
    return prior_net

def initialise_posterior(model, dataset, layers, rho_prior, prior_dist, prior_net, device, features=28*28, classes=10, neurons=100):

    if model == 'cnn':
        if dataset == 'cifar10':
            if layers == 9:
                posterior_net = ProbCNNet9l(rho_prior, prior_dist=prior_dist,
                                    device=device, init_net=prior_net).to(device)
            elif layers == 13:
                posterior_net = ProbCNNet13l(rho_prior, prior_dist=prior_dist,
                                   device=device, init_net=prior_net).to(device)
            elif layers == 15: 
                posterior_net = ProbCNNet15l(rho_prior, prior_dist=prior_dist,
                                   device=device, init_net=prior_net).to(device)
            else: 
                raise RuntimeError(f'Wrong number of layers {layers}')
        else:
            posterior_net = ProbCNNet4l(rho_prior, prior_dist=prior_dist,
                          device=device, init_net=prior_net).to(device)
    elif model == 'fcn':
        if dataset == 'cifar10':
            raise RuntimeError(f'Cifar10 not supported with given architecture {model}')
        elif dataset == 'mnist':
            posterior_net = ProbNNet4l(rho_prior, prior_dist=prior_dist,
                        device=device, init_net=prior_net).to(device)
        else: 
            posterior_net = ProbNNet3l(rho_prior, prior_dist='gaussian',
                                    device=device, features=features, classes=classes, neurons=neurons, init_net=prior_net).to(device)
    else:
        raise RuntimeError(f'Architecture {model} not supported')

    return posterior_net

def train_prior_net(prior_net, prior_net_settings, experiment_settings, alpha_mixup=1.0, val_loader=None):
    #TODO: is there a cleaner/more concise way to do this rather than 20 lines of pulling from dictionary into local vars?
    learning_rate_prior = prior_net_settings['lr']
    momentum_prior = prior_net_settings['momentum']
    objective_prior = prior_net_settings['objective']
    epochs = prior_net_settings['epochs']
    loader = prior_net_settings['loader']
    kl_penalty = prior_net_settings['kl_penalty']
    # bound_prior = prior_net_settings['bound']

    num_classes = experiment_settings['num_classes']
    delta = experiment_settings['delta']
    pmin = experiment_settings['pmin']
    delta_test = experiment_settings['delta_test']
    mc_samples = experiment_settings['mc_samples']
    device = experiment_settings['device']
    wandb_args = experiment_settings['wandb_args']
    test_loader = experiment_settings['test_loader']
    verbose = experiment_settings['verbose']
    
    section_prefix = prior_net_settings.get('section_prefix')
    if not section_prefix:
        section_prefix = "Prior/"

    prior_optimizer = optim.SGD(
        prior_net.parameters(), lr=learning_rate_prior, momentum=momentum_prior)
    #end copied from below
        
    # we select best prior based on validation loss
    best_prior = None
    loss_best_prior = float('inf')
    
    if objective_prior == 'bbb' or objective_prior == 'fquad':
        if wandb_args['log_wandb']:
            wandb.log({"DEBUG/prior:n_posterior":prior_net_settings['train_size'],"DEBUG/prior:n_bound" : prior_net_settings['n_bound']})

        bound_prior = PBBobj(objective_prior, pmin, num_classes, delta,
                delta_test, mc_samples, kl_penalty, device, n_posterior=prior_net_settings['train_size'], n_bound=prior_net_settings['n_bound'])
        optimizer_lambda = None
        lambda_var = None

        for epoch in trange(epochs):
            trainPNNet(prior_net, prior_optimizer, bound_prior, epoch, loader, lambda_var, optimizer_lambda, True, log_wandb = wandb_args['log_wandb'], wandb_section_prefix=section_prefix)
            if val_loader:
                val_loss_prior_net, _ = testStochastic(prior_net, val_loader, bound_prior, device=device)
                #log the validation loss and the bound loss
                #TODO: remove this temporary code
                test_logging = {
                    "Prior/Epoch" : epoch,
                    "Prior/val_loss" : val_loss_prior_net,
                }
                if wandb_args['log_wandb']:
                    wandb.log(test_logging)
                if val_loss_prior_net < loss_best_prior:
                    best_prior = copy.deepcopy(prior_net)
                    loss_best_prior = val_loss_prior_net
    elif objective_prior == 'erm':

        for epoch in trange(epochs):
            trainNNet(prior_net, prior_optimizer, epoch, loader,
                    device=device, verbose=verbose, log_wandb = wandb_args['log_wandb'], wandb_section_prefix=section_prefix)
            if val_loader:
                val_loss_prior_net, _ = testNNet(prior_net, val_loader, device=device)
                #log the validation loss and the bound loss
                #TODO: remove this temporary code
                test_logging = {
                    "Prior/Epoch" : epoch,
                    "Prior/val_loss" : val_loss_prior_net,
                }
                if wandb_args['log_wandb']:
                    wandb.log(test_logging)
                if val_loss_prior_net < loss_best_prior:
                    best_prior = copy.deepcopy(prior_net)
                    loss_best_prior = val_loss_prior_net
    elif objective_prior == 'mixup':

        for epoch in trange(epochs):
            trainNNetmixup(prior_net, prior_optimizer, epoch, loader,
                    device=device, verbose=verbose, alpha=alpha_mixup)
            if val_loader:
                val_loss_prior_net, _ = testNNet(prior_net, val_loader, device=device)
                if val_loss_prior_net < loss_best_prior:
                    best_prior = copy.deepcopy(prior_net)
                    loss_best_prior = val_loss_prior_net
                
    # if no stopping, we return the last prior, not the best one!
    if not val_loader:
        best_prior = copy.deepcopy(prior_net)

    if objective_prior == 'bbb' or objective_prior == 'fquad':
        loss_prior_net, error_prior_net = testStochastic(best_prior, test_loader, bound_prior, device=device)
        _, train_error_prior_net = testStochastic(best_prior, loader, bound_prior, device=device)
    else: 

        loss_prior_net, error_prior_net = testNNet(best_prior, test_loader, device=device)
        _, train_error_prior_net = testNNet(best_prior, loader, device=device)
    print(
            f"-Prior train error {train_error_prior_net :.5f}, Prior test error: {error_prior_net :.5f}")
    return loss_prior_net, error_prior_net, best_prior


def train_posterior_net(posterior_net, posterior_net_settings, experiment_settings):
    #TODO: is there a cleaner/more concise way to do this rather than 30 lines of pulling from dictionary into local vars?
    learning_rate_posterior = posterior_net_settings['lr']
    momentum_posterior = posterior_net_settings['momentum']
    objective_posterior = posterior_net_settings['objective']
    epochs = posterior_net_settings['epochs']
    loader = posterior_net_settings['loader']
    bound = posterior_net_settings['bound']
    bound_loader = posterior_net_settings['bound_loader']
    bound_loader_1batch = posterior_net_settings['bound_loader_1batch']
   
    
    kl_penalty = posterior_net_settings['kl_penalty']

    lambda_var = posterior_net_settings['lambda_var']
    optimizer_lambda = posterior_net_settings['optimizer_lambda']

    num_classes = experiment_settings['num_classes']
    delta = experiment_settings['delta']
    pmin = experiment_settings['pmin']
    delta_test = experiment_settings['delta_test']
    mc_samples = experiment_settings['mc_samples']
    
    device = experiment_settings['device']
    wandb_args = experiment_settings['wandb_args']
    test_loader = experiment_settings['test_loader']
    verbose = experiment_settings['verbose']
    verbose_test = experiment_settings['verbose_test']
    samples_ensemble = experiment_settings['samples_ensemble']
    dataset = experiment_settings['dataset']
    perc_train = experiment_settings['perc_train']
    wandb_args = experiment_settings['wandb_args']
    freq_test = experiment_settings['freq_test']
    
    toolarge = experiment_settings['toolarge']

    section_prefix = posterior_net_settings.get('section_prefix')
    if not section_prefix:
        section_prefix = "Posterior/"

    
    posterior_optimizer = optim.SGD(posterior_net.parameters(), lr=learning_rate_posterior, momentum=momentum_posterior)

    best_posterior = None
    risk_best_posterior = float('inf')
    stats_best_posterior = {}
    epoch_best_posterior = 1

    if wandb_args['log_wandb']:
        wandb.watch(posterior_net, log_freq=100)
    for epoch in trange(epochs):
        trainPNNet(posterior_net, posterior_optimizer, bound, epoch, loader, lambda_var, optimizer_lambda, verbose, wandb_args['log_wandb'], wandb_section_prefix=section_prefix)
        if verbose_test and ((epoch+1) % freq_test == 0):
            to_log = validate_pacbayes_net(posterior_net, posterior_net_settings, experiment_settings)
            to_log.update( {'Epoch' : epoch} )
            print(
            f"-Epoch {epoch :.5f}, risk: {to_log['Risk_01'] :.5f}, test error:  {to_log['Stch 01 error']:.5f}")
            if to_log['Risk_01'] < risk_best_posterior:
                best_posterior = copy.deepcopy(posterior_net)
                risk_best_posterior = to_log['Risk_01']
                stats_best_posterior = to_log
                epoch_best_posterior = epoch

            if wandb_args['log_wandb']:
                #log training metrics. Experiment hyperparams(like momentum) are logged to the config.yaml file in W&B
                to_log = {"Posterior Checkpoint/"+k: v for k, v in to_log.items()}
                wandb.log(to_log)
    if wandb_args['save_model'] and wandb_args['log_wandb']:
        torch.save(best_posterior,os.path.join(wandb.run.dir, 'best_posterior_model.pth' ))
    
    print('Best posterior...')
    print(
            f"-Epoch {epoch_best_posterior :.5f}, risk: {stats_best_posterior['Risk_01'] :.5f}, test error:  {stats_best_posterior['Stch 01 error']:.5f}")
    #return best_posterior

def validate_pacbayes_net(net, net_settings, experiment_settings): 
    learning_rate_posterior = net_settings['lr']
    momentum_posterior = net_settings['momentum']
    objective_posterior = net_settings['objective']
    epochs = net_settings['epochs']
    loader = net_settings['loader']
    bound = net_settings['bound']
    bound_loader = net_settings['bound_loader']
    bound_loader_1batch = net_settings['bound_loader_1batch']
    kl_penalty = net_settings['kl_penalty']

    lambda_var = net_settings['lambda_var']
    optimizer_lambda = net_settings['optimizer_lambda']

    num_classes = experiment_settings['num_classes']
    delta = experiment_settings['delta']
    pmin = experiment_settings['pmin']
    delta_test = experiment_settings['delta_test']
    mc_samples = experiment_settings['mc_samples']
    device = experiment_settings['device']
    wandb_args = experiment_settings['wandb_args']
    test_loader = experiment_settings['test_loader']
    verbose = experiment_settings['verbose']
    verbose_test = experiment_settings['verbose_test']
    samples_ensemble = experiment_settings['samples_ensemble']
    dataset = experiment_settings['dataset']
    perc_train = experiment_settings['perc_train']
    wandb_args = experiment_settings['wandb_args']
    
    toolarge = experiment_settings['toolarge']

    train_obj, risk_ce, risk_01, kl, loss_ce_train, loss_01_train = computeRiskCertificates(net, toolarge, bound, device=device,
    lambda_var=lambda_var, train_loader=bound_loader, whole_train=bound_loader_1batch)

    stch_loss, stch_err = testStochastic(net, test_loader, bound, device=device)
    post_loss, post_err = testPosteriorMean(net, test_loader, bound, device=device)
    ens_loss, ens_err = testEnsemble(net, test_loader, bound, device=device, samples=samples_ensemble)

    to_log = {
                    "Obj_train" : train_obj , 
                    "Risk_CE" : risk_ce , 
                    "Risk_01" : risk_01 , 
                    "KL" : kl , 
                    "Train NLL loss" : loss_ce_train , 
                    "Train 01 error" : loss_01_train , 
                    "Stch loss" : stch_loss , 
                    "Stch 01 error" : stch_err , 
                    "Post mean loss" : post_loss , 
                    "Post mean 01 error" : post_err , 
                    "Ens loss" : ens_loss , 
                    "Ens 01 error" : ens_err }
    #print(to_log)

    return to_log

def run_erm_net(prior_net_settings, posterior_net_settings, experiment_settings):
    """ Runs an experiment with a single deterministic network trained with the ERM objective.
    """
    if experiment_settings['vision_dataset']:
            erm_net_load_image_data(prior_net_settings, posterior_net_settings, experiment_settings)

    else:
        erm_net_load_uci_data(prior_net_settings, posterior_net_settings, experiment_settings)

    #initialize prior net
    prior_net = initialise_prior(experiment_settings['model_class'], experiment_settings['dataset'], experiment_settings['layers'], prior_net_settings['dropout_prob'], experiment_settings['device'], prior_net_settings["objective"], prior_net_settings['rho_prior'], prior_net_settings['weight_distribution'], init_priors_prior = prior_net_settings["initialize_prior"], features=experiment_settings['n_features'], classes=experiment_settings['num_classes'], neurons=experiment_settings['neurons'])

    #train and test the net
    loss_prior_net, error_prior_net, prior_net = train_prior_net(prior_net, prior_net_settings, experiment_settings, val_loader=experiment_settings['val_loader'])


def erm_net_load_image_data(prior_net_settings, posterior_net_settings, experiment_settings):
    """loads the data for an experiment on mnist or cifar-10 with a single deterministic network 
        trained with the ERM objective.
    """
    train, test = data.loaddataset(experiment_settings['dataset'])

    #TODO: changed back to original data loader just to test if this was responsible       
    # prior_net_settings["loader"], experiment_settings['test_loader'], _, _, _, _, experiment_settings['val_loader'] = data.loadbatches_relay_wrapper(
    #     train, test, experiment_settings['loader_kargs'], experiment_settings['batch_size'], prior=False, perc_train=experiment_settings['perc_train'], perc_prior=0.0, perc_val=experiment_settings['perc_val'])
    
    prior_net_settings["loader"], experiment_settings['test_loader'], _, _, _, _, experiment_settings['val_loader'] = data.loadbatches(
            train, test, experiment_settings['loader_kargs'], experiment_settings['batch_size'], prior=False, perc_train=experiment_settings['perc_train'], perc_prior=0.0, perc_val=experiment_settings['perc_val'])

    posterior_net_settings['train_size'] = len(prior_net_settings["loader"].dataset)
    experiment_settings['num_classes'] = len(prior_net_settings["loader"].dataset.classes)
    experiment_settings['n_features'] = None 

def erm_net_load_uci_data(prior_net_settings, posterior_net_settings, experiment_settings):
    """loads the data for an experiment on a uci dataset with a single deterministic network 
        trained with the ERM objective.
    """
    X, y = data.loaddatafrompath(experiment_settings['dataset'])
    experiment_settings['n_features'] = X.shape[1]

    # partition the data in train and test
    X_train, X_test, y_train, y_test = data.holdout_data(X, y, random_state = experiment_settings['RANDOM_STATE'], test_size=0.2)
    X_train, X_test = data.standardize(X_train, X_test)

    # if we are doing experiments in the data starvation regime
    if experiment_settings['perc_train'] < 1.0:
        X_train, _, y_train, _ = data.holdout_data(X_train, y_train, random_state = experiment_settings['RANDOM_STATE'], test_size=1-experiment_settings['perc_train'])
    

    if experiment_settings['perc_val'] > 0.0:
        X_train, X_val, y_train, y_val = data.holdout_data(X_train, y_train, random_state = experiment_settings['RANDOM_STATE'], test_size=experiment_settings['perc_val'])
        experiment_settings['val_loader'] = data.load_batches(X_val, y_val, experiment_settings['loader_kargs'])
    else:
        experiment_settings['val_loader'] = None
    # if not prior to be learnt
    if experiment_settings['oversampling']: 
        _, _, X_post, y_post = data.oversample(X_train, y_train, k_oversampling=experiment_settings['k_oversampling'], random_state=experiment_settings['RANDOM_STATE'],  perc_oversampling=experiment_settings['perc_oversampling'])
    else: 
        X_post = X_train
        y_post = y_train
    
    prior_net_settings["loader"] = data.load_batches(X_post, y_post, experiment_settings['loader_kargs'])
    experiment_settings['test_loader'] = data.load_batches(X_test, y_test, experiment_settings['loader_kargs'])

    posterior_net_settings['train_size'] = X_post.shape[0]
    experiment_settings['num_classes'] = np.unique(y_post).shape[0] 



def dynamic_programming_wrapper(experiment_args, prior_args, posterior_args, wandb_args=None):

    experiment_settings = experiment_args
    prior_net_settings = prior_args
    posterior_net_settings = posterior_args


    #log training status with weights & biases
    #check if W&B turned on and haven't initialized run(if it's already been initialized then this is a sweep experiment)
    
    
    # this makes the initialised prior the same for all bounds
    torch.manual_seed(7)
    random.seed(0)
    np.random.seed(0)
    experiment_settings['RANDOM_STATE'] = 10


    #load some useful initializations into parameter dicts
    experiment_settings['vision_dataset'] = experiment_settings['dataset'] in {'mnist', 'cifar10'}
    experiment_settings['toolarge'] = experiment_settings['model_class'] == 'cnn'
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    experiment_settings['loader_kargs']= {'num_workers': 1,
                    'pin_memory': True} if torch.cuda.is_available() else {}
    # set the hyperparameter of the prior 
    prior_net_settings['rho_prior'] = math.log(math.exp(prior_net_settings['sigma'])-1.0)



    

    """ Runs a DP experiment
    """
    #additional settings to normal args to pass:
    # experiment_settings['num_partitions']
    
    #objective_choices = ['bbb']
    #
    # 
    experiment_settings['perc_relays'] = [ 1/experiment_settings['num_partitions'] for i in range(experiment_settings['num_partitions'])]

    #TODO: load data into partitions, save in experiment_settings
    #then I only need to specify indices of data to use whenever I'd like to use them. Can use concatenate_sets function
    
    if experiment_settings['vision_dataset']:
        dynamic_programming_load_image_data(prior_net_settings, posterior_net_settings, experiment_settings)
    else:
        dynamic_programming_load_uci_data(prior_net_settings, posterior_net_settings, experiment_settings)


    @lru_cache(maxsize=None)
    def run_dynamic_programming(end_idx):
        
        #data_splits: array of portions of the dataset. sums to 1. [1/4, 1/4, 1/4, 1/4]
        #end_idx: index corresponding to an entry in data_splits. the current data portion we are examining with dp ex: 3
            
        #first, check if the result is already saved! memoization

        #calculate without prior
        #this would be training a net wherre its 'prior' is randomly/zero intitialized

        #TODO: could iterate over multiple objectives, or just used fixed bbb objective for below line

        #include wandb stuff for logging
        if wandb_args['log_wandb']:
            if wandb_args['scratch_dir'] is not None:
                run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], dir = wandb_args['scratch_dir'], project=wandb_args['wandb_project_name'], config=locals())
            else:
                run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], project=wandb_args['wandb_project_name'], config=locals())
            #if a specific name for the run is passed, set it. Otherwise use auto-generated run name
            if wandb_args.get('wandb_run_name') is not None:
                wandb.run.name = wandb_args['wandb_run_name']
            else:
                wandb.run.name = "dataset: " + experiment_settings['dataset'] + "_partitions:" + str(experiment_settings['num_partitions']) + "prior:" + str(end_idx) + "obj:" + prior_net_settings["objective"]
                
        experiment_settings['wandb_args'] = wandb_args
        #end wandb stuff
        

        no_prior_results, no_prior_net = run_dp_train_test_prior(end_idx, experiment_settings, prior_net_settings, posterior_net_settings)

        no_prior_results['network_structure'] = "prior:" + str(end_idx) + "obj:" + prior_net_settings["objective"]

        #finish prior run
        if wandb_args['log_wandb']:
            run.finish()

        if end_idx == 0:
            return no_prior_net, no_prior_results


        best_bound = no_prior_results['Risk_01']
        best_net = no_prior_net
        best_objective = None
        prior_index = None
        best_posterior_result_loggable_data = no_prior_results

        #iterates over every choice of prior
        for i in range(0,end_idx):
            #if data index < 2, only consider bbb as objective
            current_prior_net, current_prior_results = run_dynamic_programming(i)
            #import pdb; pbd.set_trace()

            for current_objective in experiment_settings['objective_choices']:
                #dp_train_test_posterior_from_prior's last 2 args specify the data to calculate the bound over, inclusive.
                #posterior should always be trained up to end_idx though!
                #if last index, should log test data to wandb
                posterior_net_settings['objective'] = current_objective

                if experiment_settings['verbose']:
                    print("trying objective:" + posterior_net_settings['objective'])


                #include wandb stuff for logging
                if wandb_args['log_wandb']:
                    if wandb_args['scratch_dir'] is not None:
                        run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], dir = wandb_args['scratch_dir'], project=wandb_args['wandb_project_name'], config=locals())
                    else:
                        run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], project=wandb_args['wandb_project_name'], config=locals())
                    #if a specific name for the run is passed, set it. Otherwise use auto-generated run name
                    if wandb_args.get('wandb_run_name') is not None:
                        wandb.run.name = wandb_args['wandb_run_name']
                    else:
                        wandb.run.name = "dataset: " + experiment_settings['dataset'] + "_partitions:" + str(experiment_settings['num_partitions']) + current_prior_results['network_structure'] + "_post:" + str(i) + "-" + str(end_idx) + "obj:" + current_objective
                        
                experiment_settings['wandb_args'] = wandb_args
                #end wandb stuff


                current_posterior_result, current_posterior_net = dp_train_test_posterior_from_prior(current_prior_net, i, end_idx, experiment_settings, prior_net_settings, posterior_net_settings)
                current_posterior_bound = current_posterior_result['Risk_01']
                print("current_posterior_bound:" + str(current_posterior_bound) + "    best_bound: "+ str(best_bound) + "   is less?:" + str(current_posterior_bound<best_bound))
                if current_posterior_bound<best_bound:
                        print("new best bound found!")
                        print("debug statement: best_prior_index=" + str(i) + "  best objective=" + current_objective)
                        best_net = current_posterior_net
                        best_posterior_result_loggable_data = current_posterior_result
                        best_posterior_result_loggable_data['current_objective'] = current_objective
                        best_posterior_result_loggable_data['prior_index'] = i
                        best_posterior_result_loggable_data['network_structure'] = current_prior_results['network_structure'] + "_post:" + str(i) + "-" + str(end_idx) + "obj:" + current_objective
                
                run.finish()
        
        
        if wandb_args['log_wandb']:
            if wandb_args['scratch_dir'] is not None:
                run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], dir = wandb_args['scratch_dir'], project=wandb_args['wandb_project_name'], config=locals())
            else:
                run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], project=wandb_args['wandb_project_name'], config=locals())
            #if a specific name for the run is passed, set it. Otherwise use auto-generated run name
            if wandb_args.get('wandb_run_name') is not None:
                wandb.run.name = wandb_args['wandb_run_name']
            else:
                wandb.run.name = "dataset: " +  experiment_settings['dataset'] + "_partitions:" + str(experiment_settings['num_partitions']) + best_posterior_result_loggable_data['network_structure'] + "final"
                

        
        if wandb_args['log_wandb']:
            #TODO: save more info on the prior network!
            best_posterior_result_loggable_data['data_idx'] = end_idx

            to_log = {"dp_result_for index:" + str(end_idx) + " / " +k: v for k, v in best_posterior_result_loggable_data.items()}
            wandb.log(to_log)
            if wandb_args['save_model']:
                torch.save(best_net,os.path.join(wandb.run.dir, "index: " + str(end_idx) + '_best_model.pth' ))

        return best_net, best_posterior_result_loggable_data



    #TODO TODO TODO TODO REMOVE THIS!!! Testing only

    @lru_cache(maxsize=None)
    def run_dynamic_programming_no_elimination(end_idx):
        
        #data_splits: array of portions of the dataset. sums to 1. [1/4, 1/4, 1/4, 1/4]
        #end_idx: index corresponding to an entry in data_splits. the current data portion we are examining with dp ex: 3
            
        #first, check if the result is already saved! memoization

        #calculate without prior
        #this would be training a net wherre its 'prior' is randomly/zero intitialized

        #TODO: could iterate over multiple objectives, or just used fixed bbb objective for below line

        #include wandb stuff for logging
        all_nets = []
        all_results = []

        if wandb_args['log_wandb']:
            if wandb_args['scratch_dir'] is not None:
                run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], dir = wandb_args['scratch_dir'], project=wandb_args['wandb_project_name'], config=locals())
            else:
                run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], project=wandb_args['wandb_project_name'], config=locals())
            #if a specific name for the run is passed, set it. Otherwise use auto-generated run name
            if wandb_args.get('wandb_run_name') is not None:
                wandb.run.name = wandb_args['wandb_run_name']
            else:
                wandb.run.name = "dataset: " + experiment_settings['dataset'] + "_partitions:" + str(experiment_settings['num_partitions']) + "prior:" + str(end_idx) + "obj:" + prior_net_settings["objective"]
                
        experiment_settings['wandb_args'] = wandb_args
        #end wandb stuff
        

        no_prior_results, no_prior_net = run_dp_train_test_prior(end_idx, experiment_settings, prior_net_settings, posterior_net_settings)

        no_prior_results['network_structure'] = "prior:" + str(end_idx) + "obj:" + prior_net_settings["objective"]

        all_nets.append(no_prior_net)
        all_results.append(no_prior_results)

        #finish prior run
        if wandb_args['log_wandb']:
            run.finish()

        if end_idx == 0:
            return all_nets, all_results


        best_bound = no_prior_results['Risk_01']
        best_net = no_prior_net
        best_objective = None
        prior_index = None
        best_posterior_result_loggable_data = no_prior_results

        #iterates over every choice of prior
        for i in range(0,end_idx):
            #if data index < 2, only consider bbb as objective
            current_prior_nets, current_prior_resultss = run_dynamic_programming_no_elimination(i)
            #import pdb; pbd.set_trace()

            for current_objective in experiment_settings['objective_choices']:
                for j in range(len(current_prior_nets)):
                    current_prior_net = current_prior_nets[j]
                    current_prior_results = current_prior_resultss[j]
                    #dp_train_test_posterior_from_prior's last 2 args specify the data to calculate the bound over, inclusive.
                    #posterior should always be trained up to end_idx though!
                    #if last index, should log test data to wandb
                    posterior_net_settings['objective'] = current_objective

                    if experiment_settings['verbose']:
                        print("trying objective:" + posterior_net_settings['objective'])


                    #include wandb stuff for logging
                    if wandb_args['log_wandb']:
                        if wandb_args['scratch_dir'] is not None:
                            run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], dir = wandb_args['scratch_dir'], project=wandb_args['wandb_project_name'], config=locals())
                        else:
                            run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], project=wandb_args['wandb_project_name'], config=locals())
                        #if a specific name for the run is passed, set it. Otherwise use auto-generated run name
                        if wandb_args.get('wandb_run_name') is not None:
                            wandb.run.name = wandb_args['wandb_run_name']
                        else:
                            wandb.run.name = "dataset: " + experiment_settings['dataset'] + "_partitions:" + str(experiment_settings['num_partitions']) + current_prior_results['network_structure'] + "_post:" + str(i) + "-" + str(end_idx) + "obj:" + current_objective
                            
                    experiment_settings['wandb_args'] = wandb_args
                    #end wandb stuff

                    current_posterior_result, current_posterior_net = dp_train_test_posterior_from_prior(current_prior_net, i, end_idx, experiment_settings, prior_net_settings, posterior_net_settings)
                    current_posterior_bound = current_posterior_result['Risk_01']
                    print("current_posterior_bound:" + str(current_posterior_bound) + "    best_bound: "+ str(best_bound) + "   is less?:" + str(current_posterior_bound<best_bound))

                    best_net = current_posterior_net
                    best_posterior_result_loggable_data = current_posterior_result
                    best_posterior_result_loggable_data['current_objective'] = current_objective
                    best_posterior_result_loggable_data['prior_index'] = i
                    best_posterior_result_loggable_data['network_structure'] = current_prior_results['network_structure'] + "_post:" + str(i) + "-" + str(end_idx) + "obj:" + current_objective
                    
                    run.finish()
                    all_nets.append(best_net)
                    all_results.append(best_posterior_result_loggable_data)

        
        
        # if wandb_args['log_wandb']:
        #     if wandb_args['scratch_dir'] is not None:
        #         run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], dir = wandb_args['scratch_dir'], project=wandb_args['wandb_project_name'], config=locals())
        #     else:
        #         run = wandb.init(settings=wandb.Settings(start_method="fork"), reinit=True, entity=wandb_args['entity'], project=wandb_args['wandb_project_name'], config=locals())
        #     #if a specific name for the run is passed, set it. Otherwise use auto-generated run name
        #     if wandb_args.get('wandb_run_name') is not None:
        #         wandb.run.name = wandb_args['wandb_run_name']
        #     else:
        #         wandb.run.name = "dataset: " +  experiment_settings['dataset'] + "_partitions:" + str(experiment_settings['num_partitions']) + best_posterior_result_loggable_data['network_structure'] + "final"
        
        # if wandb_args['log_wandb']:
        #     #TODO: save more info on the prior network!
        #     best_posterior_result_loggable_data['data_idx'] = end_idx

        #     to_log = {"dp_result_for index:" + str(end_idx) + " / " +k: v for k, v in best_posterior_result_loggable_data.items()}
        #     wandb.log(to_log)
        #     if wandb_args['save_model']:
        #         torch.save(best_net,os.path.join(wandb.run.dir, "index: " + str(end_idx) + '_best_model.pth' ))

        return all_nets, all_results


    if experiment_settings['elimination']:
        best_networks, info = run_dynamic_programming(len(experiment_settings['perc_relays'])-1)
    else:
        best_network, info = run_dynamic_programming_no_elimination(len(experiment_settings['perc_relays'])-1)

    #end of wrapper


#easy simple goal: 1/4 data split for each DP iteration
#first, train nets with array of objectives on first 1/4 of data
#second, train nets with array of objectives on first 2/4 data. Both with/without prior net, where the prior net is the one from the previous iteration with the smallest risk certificate
    #if use 1/4 prior, risk certificate based on second 1/4 of data
#third, train nets with array of objectives on first 3/4 of data. Both with/without each of 2 choices of prior net, where each prior net choice is the smallest risk certificate from preivous iterations
    #if use 1/4 prior, risk certificate based on 2/4-3/4 of data. If use 2/4 prior, risk certificate based on 3/4 of data.
#fourth, train nets with array of objectives on first 4/4 of data. Both with/without each of 3 choices of prior net, where each prior net choice is the smallest risk cetificate from previous iterations
    #if use if use 1/4 prior, risk certificate based on 2/4-4/4 of data. If use 2/4 prior, risk certificate based on 3/4-4/4 of data. If use 3/4 prior, risk certificate based on 4/4 of data



#just consider prior computed with bbb

#first pass, compute fbbb for each of the prior sections

#emphasis on readability - make explicit that memoization is occuring
#check string kernel section in kernel book

#run simple 2 or 3 stage version of this by hand to make sure that it's working, then 

#cache decorator automatically implements memoization. If looking for more functionality can be implemented from scratch, like: https://stackoverflow.com/questions/1988804/what-is-memoization-and-how-can-i-use-it-in-python


 #LOGISTICS:
    # - 4th iteration should be the outermost DP call! so it should call recursively 3 times.
    # - Need to store the results of the subproblems!

    #can use memoization decorator

    #take data splits and index of currrent split I'm at

def run_dp_train_test_prior(end_idx, experiment_settings, og_prior_net_settings, og_posterior_net_settings):
    #run_dp_train_test_prior would load dataset, and call train_prior_net and validate_pacbayes_net. very similar to run_stochastic_net
    #runs from first data chunk until the data chunk of end_idx

    #Plan of attack:
    # - minimize the work to modify to get experiment running in the first place, nothing wrong with writing ugly
    #code for this section because I can always modify it at a laterr stage. Also if I keep similar to the
    #old loading stuff i can modify both at the same time when I'm trying to clean it up.
    wandb_args = experiment_settings['wandb_args']

    #copy the dictionaries containing settings so that I don't overwrite anything imporant. 
    # Unsure if actually important/will save any time or memory
    prior_net_settings = og_prior_net_settings.copy()
    posterior_net_settings = og_posterior_net_settings.copy()

    print("running run_dp_train_test_prior")

    #TODO: think about how to implement the data loader function? ideally it will be general enough to be called
    #within this function as well as the train_postierior_from_prior function.
    #ideas:
    #   - all that I need to return is a training dataset and a bound dataset every time it's called.
    #   -other params that get set in the stochastic_net_load_***_data functions should be set once in the beginning.
    #   - such as number of classes, n_bound to use(i think i've been using the posterior net's data 
    #                                               size instead of the technically correct one)
    #   -could just pass 2 splice indices. 
    #
    if experiment_settings['vision_dataset']:

        #concatenate prior dataset
        data_indices_train = np.hstack((experiment_settings['indices_relay_data_train'][:end_idx+1]))
        print("train size:" + str(data_indices_train.shape[0]))

        if experiment_settings['perc_val']>0.0:
            data_indices_val = np.hstack((experiment_settings['indices_relay_data_val'][:end_idx+1]))
            print("val size:" + str(data_indices_val.shape[0]))
            val_sampler = data.subset_random_sampler(data_indices_val)
            experiment_settings['val_loader'] = data.data_loader_sampler(
                experiment_settings['train_dataset'], experiment_settings['batch_size'], val_sampler, False, None)
        else:
            experiment_settings['val_loader'] = None

        prior_sampler = data.subset_random_sampler(data_indices_train)
        prior_net_settings["loader"] = data.data_loader_sampler(
                experiment_settings['train_dataset'], experiment_settings['batch_size'], prior_sampler, False, None)

        prior_net_settings['bound_loader'] = prior_net_settings["loader"]

        prior_net_settings['bound_loader_1batch'] = data.data_loader_sampler(
                experiment_settings['train_dataset'], len(prior_net_settings['loader'].dataset) , prior_sampler, False, None)



        #TODO: trying out a few different values just for exploration!
        prior_net_settings['n_bound'] = experiment_settings['n_train']
        #prior_net_settings['n_bound'] = experiment_settings['n_train'] - len(prior_net_settings['bound_loader'].dataset)

        #original setting for n_bound:
        #prior_net_settings['n_bound'] = len(prior_net_settings['bound_loader'].dataset)

        prior_net_settings['train_size'] = len(prior_net_settings['loader'].dataset) 


    else:
        data_x_train, data_y_train = data.concatenate_relay_sets(experiment_settings['x_relay_data_train'][:end_idx+1], experiment_settings['y_relay_data_train'][:end_idx+1])

        print("x train shape:" + str(data_x_train.shape))
        print("y train shape:" + str(data_y_train.shape))

        if experiment_settings['perc_val']>0.0:
            data_x_val, data_y_val = data.concatenate_relay_sets(experiment_settings['x_relay_data_val'][:end_idx+1], experiment_settings['y_relay_data_val'][:end_idx+1])
            print("x val shape:" + str(data_x_val.shape))
            print("y val shape:" + str(data_y_val.shape))
            experiment_settings['val_loader'] = data.load_batches(data_x_val, data_y_val, experiment_settings['loader_kargs'])
        else:
            experiment_settings['val_loader'] = None


        prior_net_settings["loader"] = data.load_batches(data_x_train, data_y_train, experiment_settings['loader_kargs'])
        
        prior_net_settings['bound_loader'] = prior_net_settings["loader"]

        prior_net_settings['bound_loader_1batch'] = data.load_batches(data_x_train, data_y_train, experiment_settings['loader_kargs'], batch_size=-1)
    
        

        #TODO: trying out a few different values just for exploration!
        prior_net_settings['n_bound'] = len(prior_net_settings['bound_loader'].dataset)
        #before no_more_hacky_prior run, used below line for n_bound:
        #prior_net_settings['n_bound'] = experiment_settings['n_train']
        #prior_net_settings['n_bound'] = experiment_settings['n_train'] - len(prior_net_settings['bound_loader'].dataset)

        #original setting for n_bound:
        #prior_net_settings['n_bound'] = len(prior_net_settings['bound_loader'].dataset)

        prior_net_settings['train_size'] = len(prior_net_settings['loader'].dataset) 
        
        posterior_net_settings['bound_loader'] = prior_net_settings["loader"]
        posterior_net_settings['n_bound'] = len(prior_net_settings['bound_loader'].dataset)
        posterior_net_settings['train_size'] = len(prior_net_settings['loader'].dataset)

        posterior_net_settings['bound_loader_1batch'] = data.load_batches(data_x_train, data_y_train, experiment_settings['loader_kargs'], batch_size=-1)


    prior_net = initialise_prior(experiment_settings['model_class'], experiment_settings['dataset'], experiment_settings['layers'], prior_net_settings['dropout_prob'], experiment_settings['device'], prior_net_settings["objective"], prior_net_settings['rho_prior'], prior_net_settings['weight_distribution'], init_priors_prior = prior_net_settings["initialize_prior"], features=experiment_settings['n_features'], classes=experiment_settings['num_classes'], neurons=experiment_settings['neurons'])


    #TODO: I never split up validation datasets for each data split!

    if prior_net_settings['objective'] == 'flamb':
        prior_net_settings['lambda_var'] = Lambda_var(prior_net_settings['initial_lamb'], posterior_net_settings['train_size']).to(experiment_settings['device'])
        prior_net_settings['optimizer_lambda'] = optim.SGD(prior_net_settings['lambda_var'].parameters(), lr=prior_net_settings['lr'], momentum=prior_net_settings['momentum'])
    else:
        prior_net_settings['optimizer_lambda'] = None
        prior_net_settings['lambda_var'] = None

    
    prior_net_settings['bound'] = PBBobj(prior_net_settings['objective'], experiment_settings['pmin'], experiment_settings['num_classes'], experiment_settings['delta'],
                    experiment_settings['delta_test'], experiment_settings['mc_samples'], prior_net_settings['kl_penalty'], experiment_settings['device'], n_posterior=posterior_net_settings['train_size'], n_bound=posterior_net_settings['n_bound'])
    
    prior_net_settings['section_prefix'] = "training/"
    #prior_net_settings['section_prefix'] = "prior-end_idx:" + str(end_idx) + "_training/"

    if experiment_settings['prior_type'] == 'learnt':   
        loss_prior_net, error_prior_net, prior_net = train_prior_net(prior_net, prior_net_settings, experiment_settings, val_loader=experiment_settings['val_loader'])
    else: 
        loss_prior_net, error_prior_net = testNNet(prior_net, experiment_settings['test_loader'], device=experiment_settings['device'])

    if prior_net_settings["objective"] in ['bbb', 'fquad', 'fclassic']:
        to_log_prior = validate_pacbayes_net(prior_net, prior_net_settings, experiment_settings)
    
    
    if wandb_args['log_wandb']:
        to_log = {"test/" +k: v for k, v in to_log_prior.items()}
        #to_log = {"prior-end_idx:" + str(end_idx) + "_test/" +k: v for k, v in to_log_prior.items()}

        wandb.log(to_log)


    return to_log_prior, prior_net

  

def dp_train_test_posterior_from_prior(prior_net, start_idx, end_idx, experiment_settings, og_prior_net_settings, og_posterior_net_settings):

    wandb_args = experiment_settings['wandb_args']

    #copy the dictionaries containing settings so that I don't overwrite anything imporant. 
    # Unsure if actually important/will save any time or memory
    prior_net_settings = og_prior_net_settings.copy()
    posterior_net_settings = og_posterior_net_settings.copy()

    #TODO: comment out, modify experiment name and resubmit
    # if end_idx != experiment_settings['num_partitions']-1:
    #     #If not a terminal posterior, set the eta value to 0.001
    #     posterior_net_settings['kl_penalty'] = 0.001
    

    print("running dp_train_test_posterior_from_prior experiment")


    if experiment_settings['vision_dataset']:

        #first, load training data for the network
        data_indices_train = np.hstack((experiment_settings['indices_relay_data_train'][:end_idx+1]))

        #combine validation data and training data for this split. TODO:: do I rly want to do this?
        if experiment_settings['perc_val']>0.0:
            data_indices_val = np.hstack((experiment_settings['indices_relay_data_val'][:end_idx+1]))
            #import ipdb; ipdb.set_trace()
            data_indices_train_full = np.hstack((data_indices_train,data_indices_val))
        else:
            data_indices_train_full = data_indices_train

        #load the bound data for the network
        #also combines validation and training data within this split

        data_indices_bound = np.hstack((experiment_settings['indices_relay_data_train'][start_idx+1:end_idx+1]))
        
        if experiment_settings['perc_val']>0.0:
            data_indices_val = np.hstack((experiment_settings['indices_relay_data_val'][start_idx+1:end_idx+1]))

            data_indices_bound_full = np.hstack((data_indices_bound,data_indices_val))
        else:
            data_indices_bound_full = data_indices_bound
        
        posterior_sampler = data.subset_random_sampler(data_indices_train_full)
        posterior_net_settings["loader"] = data.data_loader_sampler(
                experiment_settings['train_dataset'], experiment_settings['batch_size'], posterior_sampler, False, None)

        posterior_bound_sampler = data.subset_random_sampler(data_indices_bound_full)
        posterior_net_settings['bound_loader'] = data.data_loader_sampler(
                experiment_settings['train_dataset'], experiment_settings['batch_size'], posterior_bound_sampler, False, None)

        posterior_net_settings['bound_loader_1batch'] = data.data_loader_sampler(
                experiment_settings['train_dataset'], experiment_settings['n_train'], posterior_bound_sampler, False, experiment_settings['loader_kargs'])
        
        posterior_net_settings['train_size'] = len(posterior_net_settings["loader"].dataset)
        posterior_net_settings['n_bound'] = len(posterior_net_settings["bound_loader"].dataset)


    else:        
        #Load the training data for the network

        data_x_train, data_y_train = data.concatenate_relay_sets(experiment_settings['x_relay_data_train'][:end_idx+1], experiment_settings['y_relay_data_train'][:end_idx+1])
        
        #combine validation data and training data for this split. TODO:: do I rly want to do this?
        if experiment_settings['perc_val']>0.0:
            data_x_val, data_y_val = data.concatenate_relay_sets(experiment_settings['x_relay_data_val'][:end_idx+1], experiment_settings['y_relay_data_val'][:end_idx+1])

            data_x_train_full, data_y_train_full = data.concatenate_sets(data_x_train, data_x_val, data_y_train, data_y_val )
        else:
            data_x_train_full, data_y_train_full = data_x_train, data_y_train


        #Load the bound data for the network
        #also combines validation and training data within this split

        print("trying to concatenate indices from start_idx: " + str(start_idx) + "     to end_idx: " + str(end_idx))
        data_x_bound, data_y_bound = data.concatenate_relay_sets(experiment_settings['x_relay_data_train'][start_idx+1:end_idx+1], experiment_settings['y_relay_data_train'][start_idx+1:end_idx+1])
        
        #combine validation data and training data for this split. TODO:: do I rly want to do this?
        if experiment_settings['perc_val']>0.0:
            data_x_val, data_y_val = data.concatenate_relay_sets(experiment_settings['x_relay_data_val'][start_idx+1:end_idx+1], experiment_settings['y_relay_data_val'][start_idx+1:end_idx+1])

            data_x_bound_full, data_y_bound_full = data.concatenate_sets(data_x_bound, data_x_val, data_y_bound, data_y_val )
        else:
            data_x_bound_full, data_y_bound_full = data_x_bound, data_y_bound

        
        #set the data loader
        posterior_net_settings["loader"] = data.load_batches(data_x_train_full, data_y_train_full, experiment_settings['loader_kargs'])
        #set the bound loader
        posterior_net_settings['bound_loader'] = data.load_batches(data_x_bound_full, data_y_bound_full, experiment_settings['loader_kargs'])
        posterior_net_settings['bound_loader_1batch'] = data.load_batches(data_x_bound_full, data_y_bound_full, experiment_settings['loader_kargs'], batch_size=-1)
        posterior_net_settings['train_size'] = data_x_train_full.shape[0]
        posterior_net_settings['n_bound'] = len(posterior_net_settings['bound_loader'].dataset)







    posterior_net = initialise_posterior(experiment_settings['model_class'], experiment_settings['dataset'], experiment_settings['layers'], prior_net_settings['rho_prior'], prior_net_settings['weight_distribution'], prior_net, experiment_settings['device'], features=experiment_settings['n_features'], classes=experiment_settings['num_classes'], neurons=experiment_settings['neurons'])



    if posterior_net_settings['objective'] == 'flamb':
        posterior_net_settings['lambda_var'] = Lambda_var(posterior_net_settings['initial_lamb'], posterior_net_settings['train_size']).to(experiment_settings['device'])
        posterior_net_settings['optimizer_lambda'] = optim.SGD(posterior_net_settings['lambda_var'].parameters(), lr=posterior_net_settings['lr'], momentum=posterior_net_settings['momentum'])
    else:
        posterior_net_settings['optimizer_lambda']  = None
        posterior_net_settings['lambda_var'] = None

    posterior_net_settings['bound'] = PBBobj(posterior_net_settings['objective'], experiment_settings['pmin'], experiment_settings['num_classes'], experiment_settings['delta'],
                    experiment_settings['delta_test'], experiment_settings['mc_samples'], posterior_net_settings['kl_penalty'], experiment_settings['device'], n_posterior=posterior_net_settings['train_size'], n_bound=posterior_net_settings['n_bound'])
    
    posterior_net_settings['section_prefix'] = "training/"
    #posterior_net_settings['section_prefix'] = "posterior-end_idx:" + str(end_idx) + "-start_idx:" + str(start_idx) + "-objective:" + posterior_net_settings['objective'] + "_training/"




    train_posterior_net(posterior_net, posterior_net_settings, experiment_settings)
    to_log = validate_pacbayes_net(posterior_net, posterior_net_settings, experiment_settings)
    
    if wandb_args['log_wandb']:
        wandb_log = {"test/" +k: v for k, v in to_log.items()}
        #wandb_log = {"posterior-end_idx:" + str(end_idx) + "-start_idx:" + str(start_idx) + "-objective:" + posterior_net_settings['objective'] + "test/" +k: v for k, v in to_log.items()}
        wandb.log(wandb_log)


    #first, put data into data loaders
    #initialise_posterior + bound objective
    #train_posterior_net
    #validate_pacbayes_net, log everything with a prepended string identifying the run id

    print("running dp_train_test_posterior_from_prior")

    return to_log, posterior_net



def dynamic_programming_load_image_data(prior_net_settings, posterior_net_settings, experiment_settings):
    
    train, test = data.loaddataset(experiment_settings['dataset'])

    experiment_settings['train_dataset'] = train
    
    #experiment_settings['test_dataset'] = test

    ntrain = len(train.data)
    ntest = len(test.data)

    experiment_settings['n_train'] = ntrain
    experiment_settings['n_features'] = None

    experiment_settings['num_classes'] = len(train.classes)
    
    indices = np.arange(ntrain)


    random_seed = 10
    np.random.seed(random_seed)
    np.random.shuffle(indices)

    relay_data_train_indices = [None] * len(experiment_settings['perc_relays'])

    if experiment_settings['perc_val']>0.0:
        relay_data_val_indices = [None] * len(experiment_settings['perc_relays'])

    indices_remaining = indices

    last_percentage_taken = 0
    current_percentage_unused = 1
    relay_percents_debug = []

    if experiment_settings['verbose']:
        print("relay percentages: "+ str(experiment_settings['perc_relays']))

    number_of_relays = len(experiment_settings['perc_relays'])
    for relay_index in range(number_of_relays-1):
        
        relay_percent = experiment_settings['perc_relays'][relay_index]

        relay_percents_debug.append(relay_percent)

        current_test_holdout_size = relay_percent/(current_percentage_unused - last_percentage_taken)
        if experiment_settings['verbose']:
            print("current_test_holdout_size: " + str(current_test_holdout_size))

        indices_remaining, indices_relay_chunk = data.holdout_indices(indices_remaining, random_state = experiment_settings['RANDOM_STATE'], test_size=current_test_holdout_size)
            
        if experiment_settings['perc_val']>0.0:
            indices_relay_chunk_train, indices_relay_chunk_val = data.holdout_indices(indices_relay_chunk, random_state = experiment_settings['RANDOM_STATE'], test_size=experiment_settings['perc_val'])
            relay_data_train_indices[relay_index] = indices_relay_chunk_train
            relay_data_val_indices[relay_index] = indices_relay_chunk_val
        else:
            relay_data_train_indices[relay_index] = indices_relay_chunk


        current_percentage_unused = current_percentage_unused - relay_percent


    #fill in the last chunk with the remaining data.

    indices_remaining_train, indices_remaining_val = data.holdout_indices(indices_remaining, random_state = experiment_settings['RANDOM_STATE'], test_size=experiment_settings['perc_val'])

    relay_data_train_indices[number_of_relays-1] = indices_remaining_train

    experiment_settings['indices_relay_data_train'] = relay_data_train_indices
    
    if experiment_settings['perc_val']>0.0:
        relay_data_val_indices[number_of_relays-1] = indices_remaining_val
        experiment_settings['indices_relay_data_val'] = relay_data_val_indices
    



    experiment_settings['test_loader'] = data.data_loader(test, experiment_settings['batch_size'], True, experiment_settings['loader_kargs'])
    #torch.utils.data.DataLoader(
    #        test, batch_size=experiment_settings['batch_size'], shuffle=True, experiment_settings['loader_kargs'])

    #TODO: modify the following to match new image dataset
    posterior_net_settings['train_size'] = relay_data_train_indices[number_of_relays-1].shape[0]
    posterior_net_settings['n_bound'] = relay_data_train_indices[number_of_relays-1].shape[0]
    #posterior_net_settings['n_bound'] = len(posterior_net_settings["bound_loader"].dataset)
    prior_net_settings['n_bound'] = relay_data_train_indices[0].shape[0]
    prior_net_settings['train_size'] = relay_data_train_indices[0].shape[0] 


    

def dynamic_programming_load_uci_data(prior_net_settings, posterior_net_settings, experiment_settings):
    X, y = data.loaddatafrompath(experiment_settings['dataset'])
    experiment_settings['n_features'] = X.shape[1]

    # partition the data in train and test
    X_train, X_test, y_train, y_test = data.holdout_data(X, y, random_state = experiment_settings['RANDOM_STATE'], test_size=0.2)
    X_train, X_test = data.standardize(X_train, X_test)
    experiment_settings['num_classes'] = np.unique(y_train).shape[0]

    experiment_settings['n_train'] = X_train.shape[0]


    relay_data_train_x = [None] * len(experiment_settings['perc_relays'])
    relay_data_train_y = [None] * len(experiment_settings['perc_relays'])

    if experiment_settings['perc_val']>0.0:
        relay_data_val_x = [None] * len(experiment_settings['perc_relays'])
        relay_data_val_y = [None] * len(experiment_settings['perc_relays'])

    x_remaining = X_train
    y_remaining = y_train

    last_percentage_taken = 0
    current_percentage_unused = 1
    relay_percents_debug = []

    if experiment_settings['verbose']:
        print("relay percentages: "+ str(experiment_settings['perc_relays']))

    number_of_relays = len(experiment_settings['perc_relays'])
    for relay_index in range(number_of_relays-1):
        
        relay_percent = experiment_settings['perc_relays'][relay_index]

        relay_percents_debug.append(relay_percent)

        current_test_holdout_size = relay_percent/(current_percentage_unused - last_percentage_taken)
        if experiment_settings['verbose']:
            print("current_test_holdout_size: " + str(current_test_holdout_size))
        x_remaining, x_relay_chunk, y_remaining, y_relay_chunk = data.holdout_data(x_remaining, y_remaining, random_state = experiment_settings['RANDOM_STATE'], test_size=current_test_holdout_size)
        
        if experiment_settings['perc_val']>0.0:
            x_relay_chunk_train, x_relay_chunk_val, y_relay_chunk_train, y_relay_chunk_val = data.holdout_data(x_relay_chunk, y_relay_chunk, random_state = experiment_settings['RANDOM_STATE'], test_size=experiment_settings['perc_val'])
            relay_data_train_x[relay_index] = x_relay_chunk_train
            relay_data_train_y[relay_index] = y_relay_chunk_train

            relay_data_val_x[relay_index] = x_relay_chunk_val
            relay_data_val_y[relay_index] = y_relay_chunk_val
        else:
            relay_data_train_x[relay_index] = x_relay_chunk
            relay_data_train_y[relay_index] = y_relay_chunk
        


        current_percentage_unused = current_percentage_unused - relay_percent
    
    #fill in the last chunk with the remaining data.

    x_remaining_train, x_remaining_val, y_remaining_train, y_remaining__val = data.holdout_data(x_remaining, y_remaining, random_state = experiment_settings['RANDOM_STATE'], test_size=experiment_settings['perc_val'])

    
    relay_data_train_x[number_of_relays-1] = x_remaining_train
    relay_data_train_y[number_of_relays-1] = y_remaining_train

    experiment_settings['x_relay_data_train'] = relay_data_train_x
    experiment_settings['y_relay_data_train'] = relay_data_train_y
    
    if experiment_settings['perc_val']>0.0:
        relay_data_val_x[number_of_relays-1] = x_remaining_val
        relay_data_val_y[number_of_relays-1] = y_remaining__val
        experiment_settings['x_relay_data_val'] = relay_data_val_x
        experiment_settings['y_relay_data_val'] = relay_data_val_y
    
    
    experiment_settings['test_loader'] = data.load_batches(X_test, y_test, experiment_settings['loader_kargs'])
    posterior_net_settings['train_size'] = relay_data_train_x[number_of_relays-1].shape[0]
    posterior_net_settings['n_bound'] = relay_data_train_x[number_of_relays-1].shape[0]
    #posterior_net_settings['n_bound'] = len(posterior_net_settings["bound_loader"].dataset)

    prior_net_settings['n_bound'] = relay_data_train_x[0].shape[0]
    prior_net_settings['train_size'] = relay_data_train_x[0].shape[0] 


    #TODO: I think I've loaded all the necessary elements into the dictionary, but may be missing one?
            #also: might not want to set prior net's bound loader to that of the posterior net? might be problem




def run_stochastic_net(prior_net_settings, posterior_net_settings, experiment_settings):
    """ Runs an experiment with multiple pac-bayesian prior/posterior stochastic networks trained with 
        erm or pac-bayesian objectives(final posterior must be pac-bayesian)
    """

    wandb_args = experiment_settings['wandb_args']

    if experiment_settings['vision_dataset']:
        stochastic_net_load_image_data(prior_net_settings, posterior_net_settings, experiment_settings)
    else:
        stochastic_net_load_uci_data(prior_net_settings, posterior_net_settings, experiment_settings)


    
    #looks like we are using # of samples used to train the posterior to compute prior's objective - should be prior's data size, right?
    #TODO: change this back!! first 2 commented lines are og maria's code, bottom 2 are wwhat I think it should be changed to
    prior_net_settings['bound_loader'] = posterior_net_settings['bound_loader']
    prior_net_settings['n_bound'] = len(posterior_net_settings['bound_loader'].dataset)
    prior_net_settings['train_size'] = len(posterior_net_settings['loader'].dataset)  
    # prior_net_settings['n_bound'] = prior_net_settings['train_size']
    # prior_net_settings["bound_loader"] = prior_net_settings["loader"]
    #prior_net_settings['train_size'] = len(prior_net_settings["loader"].dataset)    
    

    prior_net = initialise_prior(experiment_settings['model_class'], experiment_settings['dataset'], experiment_settings['layers'], prior_net_settings['dropout_prob'], experiment_settings['device'], prior_net_settings["objective"], prior_net_settings['rho_prior'], prior_net_settings['weight_distribution'], init_priors_prior = prior_net_settings["initialize_prior"], features=experiment_settings['n_features'], classes=experiment_settings['num_classes'], neurons=experiment_settings['neurons'])

    
    #TODO: make this into a for loop instead of just running a single time! first, functionalize this code so it can work with 2 calls for prior/posterior each
    # - what's the best way to modularize this? I will always have a prior that's initialized from the initialise_prior funciton, but potentially multiple posteriors
    # - maybe change posterior_net_settings to array of posterior net settings
    #     - define fct: create_prior_optimizers
    #     - define fct: create_posterior_optimizers
    #     - what am I usying for the the dynamic programming metric of performance? the bound?

    if prior_net_settings['objective'] == 'flamb':
        prior_net_settings['lambda_var'] = Lambda_var(prior_net_settings['initial_lamb'], posterior_net_settings['train_size']).to(experiment_settings['device'])
        prior_net_settings['optimizer_lambda'] = optim.SGD(prior_net_settings['lambda_var'] .parameters(), lr=prior_net_settings['lr'], momentum=prior_net_settings['momentum'])
    else:
        prior_net_settings['optimizer_lambda'] = None
        prior_net_settings['lambda_var'] = None

    
    prior_net_settings['bound'] = PBBobj(prior_net_settings['objective'], experiment_settings['pmin'], experiment_settings['num_classes'], experiment_settings['delta'],
                    experiment_settings['delta_test'], experiment_settings['mc_samples'], prior_net_settings['kl_penalty'], experiment_settings['device'], n_posterior=posterior_net_settings['train_size'], n_bound=posterior_net_settings['n_bound'])

    if experiment_settings['prior_type'] == 'learnt':   
        loss_prior_net, error_prior_net, prior_net = train_prior_net(prior_net, prior_net_settings, experiment_settings, val_loader=experiment_settings['val_loader'])
    else: 
        loss_prior_net, error_prior_net = testNNet(prior_net, experiment_settings['test_loader'], device=experiment_settings['device'])

    if prior_net_settings["objective"] in ['bbb', 'fquad', 'fclassic']:
        to_log_prior = validate_pacbayes_net(prior_net, prior_net_settings, experiment_settings)
    

    posterior_net = initialise_posterior(experiment_settings['model_class'], experiment_settings['dataset'], experiment_settings['layers'], prior_net_settings['rho_prior'], prior_net_settings['weight_distribution'], prior_net, experiment_settings['device'], features=experiment_settings['n_features'], classes=experiment_settings['num_classes'], neurons=experiment_settings['neurons'])

    
    if posterior_net_settings['objective'] == 'flamb':
        posterior_net_settings['lambda_var'] = Lambda_var(posterior_net_settings['initial_lamb'], posterior_net_settings['train_size']).to(experiment_settings['device'])
        posterior_net_settings['optimizer_lambda'] = optim.SGD(posterior_net_settings['lambda_var'].parameters(), lr=posterior_net_settings['lr'], momentum=posterior_net_settings['momentum'])
    else:
        posterior_net_settings['optimizer_lambda']  = None
        posterior_net_settings['lambda_var'] = None
    if wandb_args['log_wandb']:
        wandb.log({"DEBUG/posterior:n_posterior":posterior_net_settings['train_size'],"DEBUG/posterior:n_bound" : posterior_net_settings['n_bound']})

    posterior_net_settings['bound'] = PBBobj(posterior_net_settings['objective'], experiment_settings['pmin'], experiment_settings['num_classes'], experiment_settings['delta'],
                    experiment_settings['delta_test'], experiment_settings['mc_samples'], posterior_net_settings['kl_penalty'], experiment_settings['device'], n_posterior=posterior_net_settings['train_size'], n_bound=posterior_net_settings['n_bound'])
    
    # def safe_serialize(obj):
    #     default = lambda o: f"<<non-serializable: {o.__dict__.keys()}>>"
    #     return json.dumps(obj, default=default)


    # with open(prior_net_settings["objective"] + 'posterior_net_settings.json', 'w') as fp:
    #     json.dump(safe_serialize(posterior_net_settings), fp,  indent=4)
    # with open(prior_net_settings["objective"] + 'prior_net_settings.json', 'w') as fp:
    #     json.dump(safe_serialize(prior_net_settings), fp,  indent=4)
    # with open(prior_net_settings["objective"] + 'experiment_settings.json', 'w') as fp:
    #     json.dump(safe_serialize(experiment_settings), fp,  indent=4)

    #train the posterior network and log final statistics

    train_posterior_net(posterior_net, posterior_net_settings, experiment_settings)
    to_log = validate_pacbayes_net(posterior_net, posterior_net_settings, experiment_settings)
    #print(to_log)
    to_log.update( {'Epoch' : posterior_net_settings['epochs']} )
    to_log.update( {'error_prior_net' : error_prior_net} )
    to_log.update( {'loss_prior_net' : loss_prior_net} )
    if prior_net_settings["objective"] in ['bbb', 'fquad', 'fclassic']:
        to_log.update( {'risk_01_prior' : to_log_prior['Risk_01']} )
        to_log.update( {'stch_01_error_prior' : to_log_prior['Stch 01 error']} )
        to_log.update( {'postmean_01_error_prior' : to_log_prior['Post mean 01 error']} )
    # TO DO: we should log the results from training the prior (if it's a normal net just error_net_0
    # but if it's a PNN we should log stochastic errors, bound, etc)

    if wandb_args['log_wandb']:
        to_log = {"Final/"+k: v for k, v in to_log.items()}
        wandb.log(to_log)

def stochastic_net_load_image_data(prior_net_settings, posterior_net_settings, experiment_settings):
    """ Loads data for an experiment on mnist or cifar-10 with multiple pac-bayesian prior/posterior 
        stochastic networks trained with erm or pac-bayesian objectives(final posterior must be pac-bayesian)
    """
    train, test = data.loaddataset(experiment_settings['dataset'])
    # PRIOR NET IS ALREADY INITIALISED BELOW!
    #prior_net = initialise_prior(model, experiment_settings['dataset'], experiment_settings['layers'], dropout_prob, device, objective_prior, prior_net_settings['rho_prior'], prior_dist, init_priors_prior = init_priors_prior)
    
    if experiment_settings['prior_type'] == 'learnt':
        learn_prior = True
    else:
        learn_prior = False
    
    #TODO: changed back to original data loader just to test if this was responsible  
    # posterior_net_settings["loader"], experiment_settings['test_loader'], prior_net_settings["loader"], experiment_settings['bound_loader_1batch'], _, posterior_net_settings["bound_loader"], experiment_settings['val_loader'] = data.loadbatches_relay_wrapper(
    #     train, test, experiment_settings['loader_kargs'], experiment_settings['batch_size'], prior=learn_prior, perc_train=experiment_settings['perc_train'], perc_prior=experiment_settings['perc_prior'], perc_val=experiment_settings['perc_val'])
    posterior_net_settings["loader"], experiment_settings['test_loader'], prior_net_settings["loader"], prior_net_settings['bound_loader_1batch'], posterior_net_settings['bound_loader_1batch'], _, posterior_net_settings["bound_loader"], experiment_settings['val_loader'] = data.loadbatches(
        train, test, experiment_settings['loader_kargs'], experiment_settings['batch_size'], prior=learn_prior, perc_train=experiment_settings['perc_train'], perc_prior=experiment_settings['perc_prior'], perc_val=experiment_settings['perc_val'])

    posterior_net_settings['train_size'] = len(posterior_net_settings["loader"].dataset)
    prior_net_settings['train_size'] = len(prior_net_settings["loader"].dataset)
    posterior_net_settings['n_bound'] = len(posterior_net_settings["bound_loader"].dataset)
    experiment_settings['num_classes'] = len(posterior_net_settings["loader"].dataset.classes)
    experiment_settings['n_features'] = None

def stochastic_net_load_uci_data(prior_net_settings, posterior_net_settings, experiment_settings):
    """ Loads data for an experiment on a uci dataset with multiple pac-bayesian prior/posterior 
        stochastic networks trained with erm or pac-bayesian objectives(final posterior must be pac-bayesian)
    """
    X, y = data.loaddatafrompath(experiment_settings['dataset'])
    experiment_settings['n_features'] = X.shape[1]

    # partition the data in train and test
    X_train, X_test, y_train, y_test = data.holdout_data(X, y, random_state = experiment_settings['RANDOM_STATE'], test_size=0.2)
    X_train, X_test = data.standardize(X_train, X_test)

    # if we are doing experiments in the data starvation regime
    if experiment_settings['perc_train'] < 1.0:
        X_train, _, y_train, _ = data.holdout_data(X_train, y_train, random_state = experiment_settings['RANDOM_STATE'], test_size=1-experiment_settings['perc_train'])

    
    # if we want to learn the prior 
    if experiment_settings['prior_type'] == 'learnt':
        # we divide data for the prior and the bound
        X_eval, X_prior, y_eval, y_prior = data.holdout_data(X_train, y_train, random_state = experiment_settings['RANDOM_STATE'], test_size=experiment_settings['perc_prior'])

        if experiment_settings['perc_val']>0.0:
            # we divide data for the prior again to set aside some validation data
            X_prior, X_val, y_prior, y_val = data.holdout_data(X_prior, y_prior, random_state = experiment_settings['RANDOM_STATE'], test_size=experiment_settings['perc_val'])
            experiment_settings['val_loader'] = data.load_batches(X_val, y_val, experiment_settings['loader_kargs'])
        else:
            experiment_settings['val_loader'] = None

        if experiment_settings['oversampling']:
            _, _, X_prior, y_prior = data.oversample(X_prior, y_prior, k_oversampling=experiment_settings['k_oversampling'], random_state=experiment_settings['RANDOM_STATE'], perc_oversampling=experiment_settings['perc_oversampling'])
            # the posterior is learnt with all the data + synthetic data from all the data
            _, _, X_post, y_post = data.oversample(X_train, y_train, k_oversampling=experiment_settings['k_oversampling'], random_state=experiment_settings['RANDOM_STATE'], perc_oversampling=experiment_settings['perc_oversampling'])
            # ONLY from part of the real data
        else:
            X_post = X_train
            y_post = y_train

        prior_net_settings["loader"] = data.load_batches(X_prior, y_prior, experiment_settings['loader_kargs'])
        prior_net_settings['bound_loader_1batch'] = data.load_batches(X_prior, y_prior, experiment_settings['loader_kargs'], batch_size=-1)
    # if not prior to be learnt
    else:
        if experiment_settings['oversampling']: 
            _, _, X_post, y_post = data.oversample(X_train, y_train, k_oversampling=experiment_settings['k_oversampling'], random_state=experiment_settings['RANDOM_STATE'],  perc_oversampling=experiment_settings['perc_oversampling'])
        else: 
            X_post = X_train
            y_post = y_train
            X_eval = X_train
            y_eval = y_train

    posterior_net_settings["loader"] = data.load_batches(X_post, y_post, experiment_settings['loader_kargs'])
    posterior_net_settings['bound_loader'] = data.load_batches(X_eval, y_eval, experiment_settings['loader_kargs'])
    experiment_settings['test_loader'] = data.load_batches(X_test, y_test, experiment_settings['loader_kargs'])
    
    posterior_net_settings['bound_loader_1batch'] = data.load_batches(X_eval, y_eval, experiment_settings['loader_kargs'], batch_size=-1)

    posterior_net_settings['train_size'] = X_post.shape[0]
    posterior_net_settings['n_bound'] = len(posterior_net_settings["bound_loader"].dataset)

    experiment_settings['num_classes'] = np.unique(y_post).shape[0]


def test_performance_with_noise(net, net_settings, experiment_settings):
    #TODO: implement this!
    """should inject noise in network weights and return the loss/error on the same dataset it was trained on"""
    
    stch_loss, stch_err = testStochastic(net, test_loader, bound, device=device)
    post_loss, post_err = testPosteriorMean(net, test_loader, bound, device=device)
    ens_loss, ens_err = testEnsemble(net, test_loader, bound, device=device, samples=samples_ensemble)
