
from sklearn.datasets import make_classification
from collections import Counter
from imblearn.over_sampling import SMOTE
import matplotlib.pyplot as plt
import numpy as np
from sklearn import datasets
from sklearn.utils import check_random_state
from imblearn.over_sampling.base import BaseOverSampler
from imblearn.metrics.pairwise import ValueDifferenceMetric
from imblearn.utils import check_neighbors_object
from sklearn.utils import _safe_indexing
from scipy import sparse
import ipdb

class BaseSMOTE(BaseOverSampler):
    """Base class for the different SMOTE algorithms."""

    def __init__(
        self,
        sampling_strategy="auto",
        random_state=None,
        k_neighbors=5,
        n_jobs=None,
        iid=False,
    ):
        super().__init__(sampling_strategy=sampling_strategy)
        self.random_state = random_state
        self.k_neighbors = k_neighbors
        self.n_jobs = n_jobs
        self.iid = iid

    def _validate_estimator(self):
        """Check the NN estimators shared across the different SMOTE
        algorithms.
        """
        self.nn_k_ = check_neighbors_object(
            "k_neighbors", self.k_neighbors, additional_neighbor=1
        )

    def _make_samples(
        self, X, y_dtype, y_type, nn_num, n_samples, step_size=1.0
    ):
        """A support function that returns artificial samples constructed along
        the line connecting nearest neighbours.
        Parameters
        ----------
        X : {array-like, sparse matrix} of shape (n_samples, n_features)
            Points from which the points will be created.
        y_dtype : dtype
            The data type of the targets.
        y_type : str or int
            The minority target value, just so the function can return the
            target values for the synthetic variables with correct length in
            a clear format.
        nn_data : ndarray of shape (n_samples_all, n_features)
            Data set carrying all the neighbours to be used
        nn_num : ndarray of shape (n_samples_all, k_nearest_neighbours)
            The nearest neighbours of each sample in `nn_data`.
        n_samples : int
            The number of samples to generate.
        step_size : float, default=1.0
            The step size to create samples.
        Returns
        -------
        X_new : {ndarray, sparse matrix} of shape (n_samples_new, n_features)
            Synthetically generated samples.
        y_new : ndarray of shape (n_samples_new,)
            Target values for synthetic samples.
        """
        random_state = check_random_state(self.random_state)
        # select first points at random
        if self.iid:
            indices_x0 = random_state.choice(a=X.shape[0], replace=False, size=n_samples)
        else: 
            indices_x0 = random_state.choice(a=X.shape[0], replace=True, size=n_samples)

        # np.newaxis for backwards compatability with random_state
        # step size = where in the line the new points will lie in
        steps = step_size * random_state.uniform(size=n_samples)[:, np.newaxis]
        # we actually create two synthetic points from each pair of points (independently)
        steps2 = step_size * random_state.uniform(size=n_samples)[:, np.newaxis]

        # set the chosen points as used already
        used = indices_x0
        count = 0

        # choose second points (buddies)
        indices_x1 = np.zeros(shape=indices_x0.shape,dtype=int)

        # for each initial point
        for x in indices_x0:
            # we choose a buddy
            if self.iid:
                not_used_yet = [i for i in nn_num[x] if i not in used]
                if not_used_yet:
                    indices_x1[count] = random_state.choice(not_used_yet)
                    np.append(used, indices_x1[count])
            else: 
                indices_x1[count] = random_state.choice(nn_num[x])
                np.append(used, indices_x1[count])
            count+=1

        X_new1 = self._generate_samples(X, indices_x0, indices_x1, steps)
        X_new2 = self._generate_samples(X, indices_x0, indices_x1, steps2)
        y_new1 = np.full(n_samples, fill_value=y_type, dtype=y_dtype)
        X_new = np.concatenate((X_new1,X_new2), axis=0)
        y_new = np.concatenate((y_new1,y_new1), axis=0)

        return X_new, y_new

    def _generate_samples(self, X, indices_x0, indices_x1, steps):
        r"""Generate a synthetic sample.
        The rule for the generation is:
        .. math::
           \mathbf{s_{s}} = \mathbf{s_{i}} + \mathcal{u}(0, 1) \times
           (\mathbf{s_{i}} - \mathbf{s_{nn}}) \,
        where \mathbf{s_{s}} is the new synthetic samples, \mathbf{s_{i}} is
        the current sample, \mathbf{s_{nn}} is a randomly selected neighbors of
        \mathbf{s_{i}} and \mathcal{u}(0, 1) is a random number between [0, 1).
        Parameters
        ----------
        X : {array-like, sparse matrix} of shape (n_samples, n_features)
            Points from which the points will be created.
        nn_data : ndarray of shape (n_samples_all, n_features)
            Data set carrying all the neighbours to be used.
        nn_num : ndarray of shape (n_samples_all, k_nearest_neighbours)
            The nearest neighbours of each sample in `nn_data`.
        rows : ndarray of shape (n_samples,), dtype=int
            Indices pointing at feature vector in X which will be used
            as a base for creating new samples.
        cols : ndarray of shape (n_samples,), dtype=int
            Indices pointing at which nearest neighbor of base feature vector
            will be used when creating new samples.
        steps : ndarray of shape (n_samples,), dtype=float
            Step sizes for new samples.
        Returns
        -------
        X_new : {ndarray, sparse matrix} of shape (n_samples, n_features)
            Synthetically generated samples.
        """
        diffs =  X[indices_x1] - X[indices_x0]
        #ipdb.set_trace()
        if sparse.issparse(X):
            sparse_func = type(X).__name__
            steps = getattr(sparse, sparse_func)(steps)
            X_new = X[indices_x0] + steps.multiply(diffs)
        else:
            X_new = X[indices_x0] + steps * diffs

        return X_new.astype(X.dtype)

class Oversampling(BaseSMOTE):
    """Class to perform over-sampling using SMOTE.
    This object is an implementation of SMOTE - Synthetic Minority
    Over-sampling Technique as presented in [1]_.
    Read more in the :ref:`User Guide <smote_adasyn>`.
    Parameters
    ----------
    {sampling_strategy}
    {random_state}
    k_neighbors : int or object, default=5
        If ``int``, number of nearest neighbours to used to construct synthetic
        samples.  If object, an estimator that inherits from
        :class:`~sklearn.neighbors.base.KNeighborsMixin` that will be used to
        find the k_neighbors.
    {n_jobs}
    See Also
    --------
    SMOTENC : Over-sample using SMOTE for continuous and categorical features.
    SMOTEN : Over-sample using the SMOTE variant specifically for categorical
        features only.
    BorderlineSMOTE : Over-sample using the borderline-SMOTE variant.
    SVMSMOTE : Over-sample using the SVM-SMOTE variant.
    ADASYN : Over-sample using ADASYN.
    KMeansSMOTE : Over-sample applying a clustering before to oversample using
        SMOTE.
    Notes
    -----
    See the original papers: [1]_ for more details.
    Supports multi-class resampling. A one-vs.-rest scheme is used as
    originally proposed in [1]_.
    References
    ----------
    .. [1] N. V. Chawla, K. W. Bowyer, L. O.Hall, W. P. Kegelmeyer, "SMOTE:
       synthetic minority over-sampling technique," Journal of artificial
       intelligence research, 321-357, 2002.
    Examples
    --------
    >>> from collections import Counter
    >>> from sklearn.datasets import make_classification
    >>> from imblearn.over_sampling import \
    >>> X, y = make_classification(n_classes=2, class_sep=2,
    ... weights=[0.1, 0.9], n_informative=3, n_redundant=1, flip_y=0,
    ... n_features=20, n_clusters_per_class=1, n_samples=1000, random_state=10)
    >>> print('Original dataset shape %s' % Counter(y))
    Original dataset shape Counter({{1: 900, 0: 100}})
    >>> sm = SMOTE(random_state=42)
    >>> X_res, y_res = sm.fit_resample(X, y)
    >>> print('Resampled dataset shape %s' % Counter(y_res))
    Resampled dataset shape Counter({{0: 900, 1: 900}})
    """

    #@_deprecate_positional_args
    def __init__(
        self,
        *,
        sampling_strategy="minority",
        random_state=None,
        k_neighbors=5,
        n_jobs=None,
        iid = False,
        perc_oversampling=1,
    ):
        super().__init__(
            sampling_strategy=sampling_strategy,
            random_state=random_state,
            k_neighbors=k_neighbors,
            n_jobs=n_jobs,
            iid = iid,
        )
        self.perc_oversampling = perc_oversampling
        self.iid = iid

    def _fit_resample(self, X, y):
        self._validate_estimator()

        X_resampled = []#X.copy()]
        y_resampled = []#y.copy()]

        counter = Counter(y)
        # if c0 is the majority class, we resample c1
        if self.iid:
            if (counter[0]/counter[1]) > 1.5:
                sampling = {0: 0, 1: np.int(np.floor(counter[1]/2))}  
            # if c1 is the majority class, we resample c0
            elif (counter[1]/counter[0]) > 1.5:
                sampling = {0: np.int(np.floor(counter[0]/2)), 1: 0}
            # if they are balanced, we resample both!
            else:
                sampling = {0: np.int(np.floor(counter[0]/2)), 1: np.int(np.floor(counter[1]/2))}
        else: 
            if (counter[0]/counter[1]) > 1.5:
                sampling = {0: 0, 1: np.int(np.floor(counter[1]*self.perc_oversampling))}  
            # if c1 is the majority class, we resample c0
            elif (counter[1]/counter[0]) > 1.5:
                sampling = {0: np.int(np.floor(counter[0]*self.perc_oversampling)), 1: 0}
            # if they are balanced, we resample both!
            else:
                sampling = {0: np.int(np.floor(counter[0]*self.perc_oversampling)), 1: np.int(np.floor(counter[1]*self.perc_oversampling))}

        for class_sample, n_samples in sampling.items():
            
            if n_samples == 0:
                continue
            target_class_indices = np.flatnonzero(y == class_sample)
            X_class = _safe_indexing(X, target_class_indices)

            self.nn_k_.fit(X_class)
            nns = self.nn_k_.kneighbors(X_class, return_distance=False)[:, 1:]
            #ipdb.set_trace()
            X_new, y_new = self._make_samples(
                X_class, y.dtype, class_sample, nns, n_samples, 1.0
            )
            X_resampled.append(X_new)
            y_resampled.append(y_new)
            

        if sparse.issparse(X):
            X_resampled = sparse.vstack(X_resampled, format=X.format)
        else:
            X_resampled = np.vstack(X_resampled)
        y_resampled = np.hstack(y_resampled)

        return X_resampled, y_resampled

